package SOFTWELL;

import java.util.Scanner;

public class Administrador {
    private static int contadorId = 1;

    public boolean autenticar(String usuario, String clave) {
        return BaseDeDatos.autenticarAdmin(usuario, clave);
    }

    public void agregarProducto(Scanner scanner) {
    System.out.print("Ingrese el nombre del producto: ");
    String nombre = scanner.nextLine().trim();

    if (!nombre.isEmpty()) {
        double precio = -1;
        while (precio < 0) {
            System.out.print("Ingrese el precio del producto: ");
            String input = scanner.nextLine().trim();
            try {
                precio = Double.parseDouble(input);
                if (precio < 0) {
                    System.out.println("El precio debe ser positivo.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Intente con un número decimal.");
            }
        }

        Producto p = new Producto(nombre, Producto.generarId(), precio);
        BaseDeDatos.addProducto(p);
        System.out.println("Producto agregado: " + p);
    } else {
        System.out.println("Nombre vacío. No se agregó el producto.");
    }
}


    public void listarProductos() {
        if (BaseDeDatos.getAllProductos().isEmpty()) {
            System.out.println("No hay productos.");
        } else {
            for (Producto p : BaseDeDatos.getAllProductos()) {
                System.out.println(p);
            }
        }
    }

    public void eliminarProducto(Scanner scanner) {
        System.out.print("ID del producto a eliminar: ");
        while (!scanner.hasNextInt()) {
            System.out.print("Debe ser un número: ");
            scanner.nextLine();
        }
        int id = scanner.nextInt();
        scanner.nextLine();
        if (BaseDeDatos.removeProducto(id)) {
            System.out.println("Producto con ID " + id + " eliminado.");
        } else {
            System.out.println("No se encontró producto con ID " + id);
        }
    }
}
