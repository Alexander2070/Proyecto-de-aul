package SOFTWELL;

public class Producto {
    private static int contador = 1;
    private int id;
    private String nombre;
    private double precio; // Nuevo atributo

    // Constructor actualizado
    public Producto(String nombre, int id, double precio) {
        this.nombre = nombre;
        this.id = id;
        this.precio = precio;
    }

    public static int generarId() {
        return contador++;
    }

    public String getNombre() {
        return nombre;
    }

    public int getId() {
        return id;
    }

    public double getPrecio() {
        return precio;
    }

    // Método para imprimir el producto fácilmente
    @Override
    public String toString() {
        return "ID: " + id + " | Nombre: " + nombre + " | Precio: $" + String.format("%.2f", precio);
    }
}
